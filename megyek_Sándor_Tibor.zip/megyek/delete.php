<?php
require_once("db.php");

//a kiválasztott város nevének a lekérdezése, valamint a város törlése az adatbázisból paraméteres lekérdezéssel
$cityname = $_GET['originalCity'];
$sqlDelete = 'DELETE FROM varosok WHERE nev=?';
$stmt = $conn->prepare($sqlDelete);
$stmt->bind_param('s', $cityname);
$stmt->execute();
