<?php
require_once("db.php");

//kiválasztott megyeid lekérdezése, valamint a megyeid alapján a városok lekérése az adatbázisból és azok listaelemként való kiírása
$countyId = $_GET['selected'];
$sqlCities = 'SELECT nev FROM varosok WHERE megyeid=?';
$stmt = $conn->prepare($sqlCities);
$stmt->bind_param('i', $countyId);
$stmt->execute();
$result = $stmt->get_result();
    if($result->num_rows==1 ){
        $value = $result->fetch_object();
        echo '<li>'.$value->nev.'</li>';
    }
    else if($result->num_rows>1){
        while($row=$result->fetch_array())
        {
            echo '<li>'.$row[0].'</li>';
        }
    }


