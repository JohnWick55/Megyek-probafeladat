//Városok lekérdezése megye alapján
$(document).on("click", "#counties", function () {
    isSelected = false;
    let selected = $("#counties option:selected").val();
    if (selected != "default") {
        $.ajax({
            url: "getcities.php",
            method: "GET",
            data: { selected: selected },
            datatype: "html",
            success: function (data) {
                $(".cities").html(data);
            },
            error: function () {
                alert("Hiba az adat feldolgozása során.");
            }
        });
    }
});

//kiválasztott megye és város deklarálása
let isSelected = false;
let originalCity = "";

//a lista mezőkre kattintva beviteli mezőben jelenik meg az adott város
$(document).on("click", "li", function () {
    if (!isSelected) {
        originalCity = $(this).text();
        $(this).replaceWith("<input id='name' value=" + $(this).text() + "><input class='button' type='button' value='töröl' id='delete'><input type='button' class='button'  value='módosít' id='modify'><input class='button'  type='button' value='mégsem' id='cancel'>")
        isSelected = true;
    }
})

//a mégse gombra kattintva eltűnik a beviteli mező és a hozzá tartozó gombok és listaelemként jelenik meg a kiválasztott város eredeti neve
$(document).on("click", "#cancel", function () {
    $(this).replaceWith("<li>" + originalCity + "</li>");
    $("#name").remove();
    $("#delete").remove();
    $("#modify").remove();
    isSelected = false;
})

//a módosítás gombra kattintva módosul a kiválasztott város az adatbázisban és a listában
$(document).on("click", "#modify", function () {
    let modified = $.trim($("#name").val());
    if(modified!=""){
        $.ajax({
            url: "modify.php",
            method: "GET",
            data: { modified: modified, originalCity: originalCity },
            datatype: "html",
            success: function () {
                $("#name").replaceWith("<li>" + modified + "</li>");
                $("#cancel").remove();
                $("#delete").remove();
                $("#modify").remove();
                isSelected = false;
            },
            error: function () {
                alert("Hiba az adat feldolgozása során.");
            }
        });
    } 
})

//a törlés gombra kattintva kitörlődik a város az adatbázisból és a listából
$(document).on("click", "#delete", function () {
    $.ajax({
        url: "delete.php",
        method: "GET",
        data: { originalCity: originalCity },
        datatype: "html",
        success: function () {
            $("#name").remove();
            $("#cancel").remove();
            $("#delete").remove();
            $("#modify").remove();
            isSelected = false;
        },
        error: function () {
            alert("Hiba az adat feldolgozása során.");
        }
    });
})

//a hozzáadás gombra kattintva a város hozzáadódik az adatbázishoz a kiválasztott megyéhez rendelve
$(document).on("click", "#add", function () {
    if($("#counties option:selected").val()!="default"){
        let newCity = $("#newCity").val();
        let selected = $("#counties option:selected").val();
        console.log(newCity);
        console.log(selected);
        $.ajax({
            url: "add.php",
            method: "GET",
            data: { newCity: newCity, selected: selected },
            datatype: "html",
            success: function () {
                let matchCity=false;
                let list = $("ul").children();
                for (let i = 0; i < list.length; i++) {
                    let arrValue = list[i].innerHTML;
                    if(arrValue==newCity){
                        matchCity=true;
                    }
                }
                if(!matchCity){
                    $("ul").append("<li>" + newCity + "</li>");
                }    
            },
            error: function () {
                alert("Hiba az adat feldolgozása során.");
            }
        });
    }
    
})


