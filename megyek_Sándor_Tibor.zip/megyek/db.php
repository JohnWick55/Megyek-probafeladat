<?php

//csatlakozás az adatbázishoz
$conn = mysqli_connect('localhost','root','','megye');

if($conn->errno){
    echo 'Hiba az adatbázishoz való csatlakozás során.';
}
if(!$conn->set_charset('utf8')){
    echo 'Hiba az adatbázishoz való csatlakozás során.';
}
