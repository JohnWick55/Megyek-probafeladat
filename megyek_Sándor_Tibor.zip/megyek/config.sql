-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2022. Jan 10. 20:51
-- Kiszolgáló verziója: 10.4.22-MariaDB
-- PHP verzió: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `megye`
--
CREATE DATABASE IF NOT EXISTS `megye` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `megye`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `megyek`
--

CREATE TABLE `megyek` (
  `id` int(11) NOT NULL,
  `nev` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- A tábla adatainak kiíratása `megyek`
--

INSERT INTO `megyek` (`id`, `nev`) VALUES
(6, 'Bács-Kiskun'),
(7, 'Baranya'),
(8, 'Békés'),
(9, 'Borsod-Abaúj-Zemplén'),
(10, 'Csongrád-Csanád'),
(11, 'Fejér'),
(12, 'Győr-Moson-Sopron'),
(13, 'Hajdú-Bihar'),
(14, 'Heves'),
(15, 'Jász-Nagykun-Szolnok'),
(19, 'Komárom-Esztergom'),
(16, 'Nógrád	'),
(17, 'Pest'),
(18, 'Somogy'),
(20, 'Szabolcs-Szatmár-Bereg'),
(21, 'Tolna'),
(22, 'Vas'),
(23, 'Veszprém'),
(26, 'Zala');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `varosok`
--

CREATE TABLE `varosok` (
  `id` int(11) NOT NULL,
  `nev` varchar(150) NOT NULL,
  `megyeid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `megyek`
--
ALTER TABLE `megyek`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nev` (`nev`);

--
-- A tábla indexei `varosok`
--
ALTER TABLE `varosok`
  ADD KEY `megyeid` (`megyeid`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `megyek`
--
ALTER TABLE `megyek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `varosok`
--
ALTER TABLE `varosok`
  ADD CONSTRAINT `varosok_ibfk_1` FOREIGN KEY (`megyeid`) REFERENCES `megyek` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
