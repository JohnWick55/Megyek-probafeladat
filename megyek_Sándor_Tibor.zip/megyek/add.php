<?php
require_once("db.php");

//új város nevének és a megyeid-nak a lekérdezése valamint azok hozzáadása az adatbázishoz paraméteres lekérdezéssel
$newCity = $_GET["newCity"];
$countyId = $_GET["selected"];
$sqlAdd = 'INSERT INTO varosok (nev, megyeid) VALUES (?,?)';
$stmt = $conn->prepare($sqlAdd);
$stmt->bind_param('si', $newCity,$countyId);
$stmt->execute();