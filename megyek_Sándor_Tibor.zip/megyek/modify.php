<?php
require_once("db.php");

//a módosított város lekérdezése és az ezzel a névvel egyező város módosítása az adatbázisban
$modified = $_GET['modified'];
$originalCity = $_GET['originalCity'];
$sqlModify = 'UPDATE varosok SET nev = ? WHERE nev = ?';
$stmt = $conn->prepare($sqlModify);
$stmt->bind_param('ss', $modified,$originalCity);
$stmt->execute();

