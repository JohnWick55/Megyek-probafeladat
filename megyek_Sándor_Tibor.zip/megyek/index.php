<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="jquery-3.5.1.min.js"></script>
    <script src="app.js"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="panel">
        <select name="" id="counties">
            <option value="default" default>Válasszon</option>
            <?php
                require_once('db.php');

                //megyék lekérdezése
                $sqlC = "SELECT id, nev FROM megyek";
                $resultC = $conn->query($sqlC);
                
                //megyék beolvasása option-ökbe 
                while($row = $resultC->fetch_array())
                {
                    echo '<option value="'.$row[0].'">'.$row[1].'</option>';
                }

            ?>
        </select>
        <input id="newCity" type="text" placeholder="Új város">
        <input class="button" id="add" type="button" value="Felvesz">
        <ul class="cities"></ul>
        </div>
        
    </div>
</body>

</html>